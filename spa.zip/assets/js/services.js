/*function service() {
    let ser = document.querySelector('.servicesListHover');

    ser.style.width = 50 * 2 + '%';
    ser.style.height = 15 * 2 + '%';


    ser.addEventListener('transitioned', function services() {
            ser.removeEventListener('transitioned',services);
    })

}

service();*/



