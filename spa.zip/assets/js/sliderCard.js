$(function() {

    $( '#fs-slider' ).imgslider();

});